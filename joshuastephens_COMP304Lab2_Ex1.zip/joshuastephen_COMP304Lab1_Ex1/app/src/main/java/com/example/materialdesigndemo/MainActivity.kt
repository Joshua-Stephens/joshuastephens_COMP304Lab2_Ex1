package com.example.materialdesigndemo

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

enum class TaskStatus {
    PENDING, COMPLETED
}

data class Task(
    var title: String,
    var description: String,
    var status: TaskStatus = TaskStatus.PENDING,
    var dueDate: LocalDateTime?
)

class MainActivity : ComponentActivity() {
    private lateinit var viewModel: TaskViewModel

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel = TaskViewModel()

        setContent {
            TaskManagerApp(viewModel)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    @Composable
    fun TaskManagerApp(viewModel: TaskViewModel) {
        val navController = rememberNavController()
        val tasks by viewModel.tasks.collectAsState()
        var textSize by remember { mutableStateOf(16.sp) }

        MaterialTheme {
            NavHost(navController, startDestination = "home") {
                composable("home") { HomeScreen(navController, tasks, viewModel, textSize) }
                composable("create") { CreateTaskScreen(navController, viewModel, textSize) }
                composable("edit/{taskIndex}") { backStackEntry ->
                    val taskIndex = backStackEntry.arguments?.getString("taskIndex")?.toInt()
                    ViewEditTaskScreen(navController, taskIndex, viewModel, textSize)
                }
                composable("settings") {
                    SettingsScreen(navController) { newSize ->
                        textSize = newSize
                    }
                }
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @RequiresApi(Build.VERSION_CODES.O)
    @Composable
    fun HomeScreen(navController: NavHostController, tasks: List<Task>, viewModel: TaskViewModel, textSize: TextUnit) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Task Manager", fontSize = textSize) },
                    actions = {
                        IconButton(onClick = { navController.navigate("settings") }) {
                            Text("Settings", fontSize = textSize, color = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color(0xFF6200EE))
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { navController.navigate("create") }) {
                    Text("+", fontSize = textSize)
                }
            }
        ) { paddingValues ->
            LazyColumn(modifier = Modifier.padding(paddingValues)) {
                itemsIndexed(tasks) { index, task ->
                    Card(
                        modifier = Modifier.padding(8.dp).fillMaxWidth(),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFBBDEFB))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = task.title, style = MaterialTheme.typography.titleMedium.copy(fontSize = textSize))
                            Text(text = task.description.take(50) + "...", style = MaterialTheme.typography.bodyMedium.copy(fontSize = textSize))
                            task.dueDate?.let {
                                Text(text = "Due: ${it.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))}", fontSize = textSize)
                            }
                            Text(
                                text = task.status.name,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = textSize),
                                color = if (task.status == TaskStatus.COMPLETED) Color.Green else Color.Red
                            )
                            Row {
                                TextButton(
                                    onClick = {
                                        viewModel.toggleTaskStatus(index)
                                    },
                                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF6200EE))
                                ) {
                                    Text("Toggle Status", fontSize = textSize)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = { navController.navigate("edit/$index") },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF03DAC6))
                                ) {
                                    Text("Edit", fontSize = textSize)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    @Composable
    fun CreateTaskScreen(navController: NavHostController, viewModel: TaskViewModel, textSize: TextUnit) {
        var title by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var dueDate by remember { mutableStateOf<LocalDateTime?>(null) }
        var showDatePicker by remember { mutableStateOf(false) }
        var showTimePicker by remember { mutableStateOf(false) }
        var selectedYear by remember { mutableStateOf(0) }
        var selectedMonth by remember { mutableStateOf(0) }
        var selectedDay by remember { mutableStateOf(0) }

        Column(modifier = Modifier.padding(16.dp)) {
            TextField(value = title, onValueChange = { title = it }, label = { Text("Title", fontSize = textSize) })
            TextField(value = description, onValueChange = { description = it }, label = { Text("Description", fontSize = textSize) }, modifier = Modifier.weight(1f))

            Button(onClick = { showDatePicker = true }) {
                Text("Select Due Date", fontSize = textSize, color = Color.White)
            }

            if (showDatePicker) {
                DatePickerDialog(
                    this@MainActivity,
                    { _, year, month, dayOfMonth ->
                        selectedYear = year
                        selectedMonth = month + 1
                        selectedDay = dayOfMonth
                        dueDate = LocalDateTime.of(year, selectedMonth, dayOfMonth, 0, 0)
                        showDatePicker = false
                        showTimePicker = true
                    },
                    Calendar.getInstance().get(Calendar.YEAR),
                    Calendar.getInstance().get(Calendar.MONTH),
                    Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
                ).show()
            }

            if (showTimePicker) {
                TimePickerDialog(
                    this@MainActivity,
                    { _, hour, minute ->
                        dueDate = dueDate?.withHour(hour)?.withMinute(minute)
                        showTimePicker = false
                    },
                    Calendar.getInstance().get(Calendar.HOUR_OF_DAY),
                    Calendar.getInstance().get(Calendar.MINUTE),
                    true
                ).show()
            }

            Button(
                onClick = {
                    viewModel.addTask(title, description, dueDate)
                    navController.navigate("home")
                }
            ) {
                Text("Save", fontSize = textSize)
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    @Composable
    fun ViewEditTaskScreen(navController: NavHostController, taskIndex: Int?, viewModel: TaskViewModel, textSize: TextUnit) {
        if (taskIndex != null) {
            val task = viewModel.tasks.collectAsState().value[taskIndex]
            var title by remember { mutableStateOf(task.title) }
            var description by remember { mutableStateOf(task.description) }
            var dueDate by remember { mutableStateOf(task.dueDate) }
            var showTimePicker by remember { mutableStateOf(false) }
            var hour by remember { mutableStateOf(0) }
            var minute by remember { mutableStateOf(0) }

            Column(modifier = Modifier.padding(16.dp)) {
                TextField(value = title, onValueChange = { title = it }, label = { Text("Title", fontSize = textSize) })
                TextField(value = description, onValueChange = { description = it }, label = { Text("Description", fontSize = textSize) })

                Button(onClick = {
                    val calendar = Calendar.getInstance()
                    hour = calendar.get(Calendar.HOUR_OF_DAY)
                    minute = calendar.get(Calendar.MINUTE)
                    showTimePicker = true
                }) {
                    Text("Select Due Date and Time", fontSize = textSize, color = Color.White)
                }

                if (showTimePicker) {
                    TimePickerDialog(
                        this@MainActivity,
                        { _, selectedHour, selectedMinute ->
                            dueDate = dueDate?.withHour(selectedHour)?.withMinute(selectedMinute)
                            showTimePicker = false
                        },
                        hour,
                        minute,
                        true
                    ).show()
                }

                Button(onClick = {
                    viewModel.updateTask(taskIndex, title, description, dueDate)
                    navController.navigate("home")
                }) {
                    Text("Update Task", fontSize = textSize)
                }
            }
        }
    }

    @Composable
    fun SettingsScreen(navController: NavHostController, onTextSizeChange: (TextUnit) -> Unit) {
        var textSizeOptions = listOf("Normal", "Large")
        var selectedSize by remember { mutableStateOf("Normal") }

        Column(modifier = Modifier.padding(16.dp)) {
            Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            textSizeOptions.forEach { size ->
                Button(
                    onClick = {
                        selectedSize = size
                        onTextSizeChange(if (size == "Large") 30.sp else 16.sp)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6200EE))
                ) {
                    Text(size, fontSize = 16.sp, color = Color.White)
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { navController.navigate("home") }) {
                Text("Back to Home", fontSize = 16.sp)
            }
        }
    }
}
