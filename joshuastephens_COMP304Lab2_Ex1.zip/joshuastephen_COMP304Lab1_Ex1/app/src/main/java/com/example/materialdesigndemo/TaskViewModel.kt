package com.example.materialdesigndemo

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.time.LocalDateTime

class TaskViewModel : ViewModel() {
    private val _tasks = MutableStateFlow<List<Task>>(emptyList())
    val tasks: StateFlow<List<Task>> = _tasks

    fun addTask(title: String, description: String, dueDate: LocalDateTime?) {
        val newTask = Task(title = title, description = description, dueDate = dueDate)
        _tasks.value = _tasks.value + newTask
    }

    fun updateTask(index: Int, title: String, description: String, dueDate: LocalDateTime?) {
        val updatedTask = _tasks.value[index].copy(title = title, description = description, dueDate = dueDate)
        _tasks.value = _tasks.value.toMutableList().apply { set(index, updatedTask) }
    }

    fun toggleTaskStatus(index: Int) {
        _tasks.value = _tasks.value.toMutableList().apply {
            val task = this[index]
            val newStatus = if (task.status == TaskStatus.COMPLETED) TaskStatus.PENDING else TaskStatus.COMPLETED
            this[index] = task.copy(status = newStatus)
        }
    }
}
